package GMM;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class sigmaMapper
    extends Mapper<LongWritable, Text, Text, Text>{
	public static ArrayList<Matrix> head2 = new ArrayList<>();
	public static Integer count = 0;
    public void map(LongWritable key, Text value, Context context){
    	if(sigmaMain.first) {
    		head2 = new ArrayList<>();
    		sigmaMain.first=false;
    		gmm.sigma = new ArrayList<>();
    		for (int i=0; i<gmm.kind;i++) {
    			head2.add(DenseMatrix.Factory.zeros(gmm.dim, gmm.dim));
    		}
    	}
    	String line = value.toString();
    	Matrix y = Function.getmatrix(line);
    	for(int i = 0;i<gmm.kind;i++) {
    		head2.set(i, head2.get(i).plus((y.minus(gmm.miu.get(i)).mtimes(y.minus(gmm.miu.get(i)).transpose())).times(gmm.lambda.get(count).getAsDouble(i, 0))));
    	}
    	count++;
    }
}
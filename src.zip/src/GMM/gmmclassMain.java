package GMM;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.ujmp.core.Matrix;

public class gmmclassMain {
	public static ArrayList<Matrix> lambda = new ArrayList<>();
	public static PrintWriter write;
	
	public static void readlambda(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		while(sc.hasNextLine()) {
				lambda.add(Function.getmatrix(sc.nextLine()));
		}
		sc.close();
	}
	
	public static void Main(String[] arg) throws Exception {
        Job job = new Job();
        job.setJarByClass(gmmclassMain.class);
        job.setJobName("Hierarchical cluster");
        
        FileInputFormat.addInputPath(job, new Path(arg[0]));
        FileOutputFormat.setOutputPath(job, new Path(arg[1]));

        job.setMapperClass(gmmclassMapper.class);
        job.setReducerClass(gmmclassReducer.class);
        job.setNumReduceTasks(0);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
	}
	
	public static void main(String[] args) throws Exception{
		String filepath = "G:\\gmm\\lambda32.txt";
		readlambda(filepath);
		args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\1.txt", "G:\\gmm\\result"};
		write = new PrintWriter("G:\\gmm\\result.txt");
		Main(args);
		write.close();
	}

}

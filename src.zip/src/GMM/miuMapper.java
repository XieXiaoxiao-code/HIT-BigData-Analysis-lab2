package GMM;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class miuMapper
    extends Mapper<LongWritable, Text, Text, Text>{
	public static ArrayList<Matrix> head = new ArrayList<>();
	public static ArrayList<Double> tail = new ArrayList<>();
	public static Integer count = 0;
    public void map(LongWritable key, Text value, Context context) {
    	if(miuMain.first) {
    		head = new ArrayList<>();
    		tail = new ArrayList<>();
    		miuMain.first=false;
    		gmm.miu = new ArrayList<>();
    		for (int i=0; i<gmm.kind;i++) {
    			head.add(DenseMatrix.Factory.zeros(gmm.dim, 1));
    			tail.add(0.0);
    		}
    	}
    	String line = value.toString();
    	Matrix y = Function.getmatrix(line);
    	for(int i = 0;i<gmm.kind;i++) {
    		head.set(i, head.get(i).plus(y.times(gmm.lambda.get(count).getAsDouble(i, 0))));
    		tail.set(i, tail.get(i)+gmm.lambda.get(count).getAsDouble(i, 0));
    	}
    	count++;
    }
}
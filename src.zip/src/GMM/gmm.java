package GMM;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class gmm {
	public static Integer kind = 18;   //������
	public static Integer dim = 20;    //ά��
	public static Integer num = 1500000;   //������
	public static ArrayList<Matrix> lambda = new ArrayList<>();
	public static ArrayList<Double> alpha = new ArrayList<>();
	public static ArrayList<Matrix> miu = new ArrayList<>();
	public static ArrayList<Matrix> sigma = new ArrayList<>();

	public static void init(String filepath1, String filepath2) throws FileNotFoundException {
		PrintWriter write1 = new PrintWriter(new File(filepath1)); //alpha
		PrintWriter write2 = new PrintWriter(new File(filepath2)); //sigma
		for(int i = 0;i<kind;i++) {
			write1.println(1.0/kind);
			for(int j = 0;j<dim;j++) {
				for(int m = 0;m<dim;m++) {
					if(m==j) {
						write2.print("1000.0 ");
					}
					else {
						write2.print("0.0 ");
					}					
				}
				write2.println();
			}
		}
		write1.close();
		write2.close();
	}
	
	public static void readalpha(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		int i = 0;
		while(sc.hasNextLine()&&i<kind) {
			alpha.add(Double.parseDouble(sc.nextLine()));
			i++;
		}
		sc.close();
	}
	
	public static void readmiu(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		while(sc.hasNextLine()) {
			miu.add(Function.getmatrix(sc.nextLine()));
		}
		sc.close();
	}
	
	public static void readsigma(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		int i = 0;
		while(sc.hasNextLine()&&i<kind) {
			Matrix sigma0 = DenseMatrix.Factory.zeros(dim, dim);
			for(int m = 0;m<dim;m++) {
				String[] T = sc.nextLine().split(" ");
				for(int n = 0;n<dim;n++) {
					sigma0.setAsDouble(Double.parseDouble(T[n]), m, n);
				}
			}
			i++;
			sigma.add(sigma0);
		}
		sc.close();
	}
	
	public static void readlambda(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		while(sc.hasNextLine()) {
				lambda.add(Function.getmatrix(sc.nextLine()));
		}
		sc.close();
	}
	
	
	public static void writealpha(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		for(int i = 0;i<kind;i++) {
			write.println(alpha.get(i));
		}
		write.close();
	}
	
	public static void writemiu(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		for(int i = 0;i<kind;i++) {
			for(int j = 0;j<dim-1;j++) {
				write.print(miu.get(i).getAsDouble(j, 0)+",");
			}
			write.println(miu.get(i).getAsDouble(dim-1, 0));
		}
		write.close();
	}
	
	public static void writesigma(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		for(int i = 0;i<kind;i++) {
			for(int j = 0;j<dim;j++) {
				for(int n = 0;n<dim;n++) {
					write.print(sigma.get(i).getAsDouble(j, n)+" ");
				}
				write.println();
			}
		}
		write.close();
	}
	
	public static void writelambda(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		for(int i = 0;i<num;i++) {
			for(int j = 0;j<kind-1;j++) {
				write.print(lambda.get(i).getAsDouble(j, 0)+",");
			}
			write.println(lambda.get(i).getAsDouble(kind-1, 0));
		}
		write.close();		
	}
	
	public static void main(String[] args) throws Exception {
		String filepath1 = "G:\\gmm\\alpha";
		String filepath2 = "G:\\gmm\\sigma";
		String filepath3 = "G:\\gmm\\miu";
		String filepath4 = "G:\\gmm\\lambda";
		init(filepath1+"0.txt", filepath2+"0.txt");
		for(Integer i=0;i<10;i++) {
			readalpha(filepath1+i.toString()+".txt");
			readsigma(filepath2+i.toString()+".txt");
			readmiu(filepath3+i.toString()+".txt");
			args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\1.txt", "G:\\gmm\\output1"+i.toString()};
			lambda = new ArrayList<>();
			lambdaMain.Main(args);
			writelambda(filepath4+((Integer)(i+1)).toString()+".txt");
			miuMain.first = true;
			miuMapper.count = 0;
			args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\1.txt", "G:\\gmm\\output2"+i.toString()};
			miuMain.Main(args);
			alpha = new ArrayList<>();
			for(int j = 0;j<kind;j++) {
				miu.add(miuMapper.head.get(j).times(1.0/miuMapper.tail.get(j)));
				alpha.add(miuMapper.tail.get(j)/num);
			}
			writemiu(filepath3+((Integer)(i+1)).toString()+".txt");
			sigma = new ArrayList<>();
			args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\1.txt", "G:\\gmm\\output3"+i.toString()};
			sigmaMain.Main(args);
			for(int j = 0;j<kind;j++) {
				sigma.add(sigmaMapper.head2.get(j).times(1.0/miuMapper.tail.get(j)));
			}
			writealpha(filepath1+((Integer)(i+1)).toString()+".txt");
			writesigma(filepath2+((Integer)(i+1)).toString()+".txt");
			
		}
	}
	
}

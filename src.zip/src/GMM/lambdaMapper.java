package GMM;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.ujmp.core.Matrix;

public class lambdaMapper
    extends Mapper<LongWritable, Text, Text, Text>{
	public static Integer i = 0;
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
    	String line = value.toString();
    	Matrix y = Function.getmatrix(line);
    	gmm.lambda.add(Function.lambda(y));
    }
}
package GMM;

import java.util.ArrayList;

import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class Function {
	public static Double gauss(Matrix y, Matrix miu, Matrix sigma) {
		long length = y.getRowCount();
		Double a = 1.0/(Math.pow(2*Math.PI, length/2)*Math.sqrt(sigma.det()));
		Matrix b = ((y.minus(miu)).transpose().mtimes(sigma.inv())).mtimes(y.minus(miu));
		a = a*Math.pow(Math.E, (-1.0/2)*b.getAsDouble(0, 0));
		return a;
	}
	
	public static Matrix getmatrix(String S) {
		String[] T = S.split(",");
		int length = T.length;
		Matrix array = DenseMatrix.Factory.zeros(length, 1);
		for (int i=0;i<length;i++) {
			array.setAsDouble(Double.parseDouble(T[i]), i, 0);;
		}
		return array;
	}
	
	public static Matrix lambda(Matrix y) {
		Matrix lambda = DenseMatrix.Factory.zeros(gmm.kind, 1);
		ArrayList<Double> r = new ArrayList<>();
		Double sum = 0.0;
		for(int i = 0;i<gmm.kind;i++) {
			Double tem = gmm.alpha.get(i)*gauss(y, gmm.miu.get(i), gmm.sigma.get(i));
			r.add(tem);
			sum+=tem;
		}
		for(int i = 0;i<gmm.kind;i++) {
			lambda.setAsDouble(r.get(i)/sum, i, 0);
		}
		return lambda;
	}

}

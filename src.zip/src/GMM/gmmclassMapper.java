package GMM;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class gmmclassMapper
    extends Mapper<LongWritable, Text, Text, Text>{
	public static Integer i = 0;
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
    	Double max = 0.0;
    	Integer max_i = 0;
    	for(int j = 0;j<gmm.kind;j++) {
    		if(gmmclassMain.lambda.get(i).getAsDouble(j, 0)>max) {
    			max = gmmclassMain.lambda.get(i).getAsDouble(j, 0);
    			max_i = j;
    		}
    	}gmmclassMain.write.println(max_i);
    	i++;
    }
}
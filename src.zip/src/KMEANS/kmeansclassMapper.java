package KMEANS;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import TUPLE.DoubleTuple;

public class kmeansclassMapper
    extends Mapper<LongWritable, Text, Text, Text>{
	public static Integer i = 0;
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
    	Double min = Double.MAX_VALUE;
    	Integer min_i = 0;
    	DoubleTuple D = new DoubleTuple(value.toString());
    	for(int j=0;j<kmeans.kind;j++) {
    		if(min>kmeansclassMain.centername.get(j).getDistance(D)) {
    			min = kmeansclassMain.centername.get(j).getDistance(D);
    			min_i = j;
    		}
    	}
    	kmeansclassMain.write.println(min_i);
    	i++;
    }
}
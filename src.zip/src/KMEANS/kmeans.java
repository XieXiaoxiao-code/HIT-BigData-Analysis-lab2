package KMEANS;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import TUPLE.DoubleTuple;
import TUPLE.NewArrayList;


public class kmeans{
	public static ArrayList<DoubleTuple> centername = new ArrayList<DoubleTuple>();
	public static HashMap<String, NewArrayList<DoubleTuple>> centerset = new HashMap<>();
	public static Integer kind = 18;
	@SuppressWarnings("deprecation")
	public static void Main(String[] args) throws Exception {
        Job job = new Job();
        job.setJarByClass(kmeans.class);
        job.setJobName("K-means");
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setMapperClass(kmeansMapper.class);
        job.setReducerClass(kmeansReducer.class);
        job.setNumReduceTasks(0);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
    }
	
	public static void readcenter(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		while(sc.hasNextLine()) {
			String next = sc.nextLine();
			centername.add(new DoubleTuple(next));
			centerset.put(next, new NewArrayList<DoubleTuple>(new DoubleTuple(next)));
		}	
	}
	
	public static void combine(DoubleTuple d) {
		int S = centername.size();
		Double mindis = Double.MAX_VALUE;
		int min_i = 0;
		for(int i = 0;i<S;i++) {
			Double nowdis = d.getDistance(centername.get(i));
			if(nowdis<mindis) {
				mindis = nowdis;
				min_i = i;
			}
		}
		centerset.get(centername.get(min_i).toString()).add(d);
	}
	
	public static void writecenter(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		int S = centername.size();
		for (int i = 0;i<S;i++) {
			write.println(centerset.get(centername.get(i).toString()).getcenter().toString());
		}
		write.close();
	}
	
	public static void main(String[] args) throws Exception{
		int size = 23;
		String path = "G:\\kmeans\\";
		for(Integer i = 0;i<size;i++) {
			centername = new ArrayList<DoubleTuple>();
			centerset = new HashMap<>();
			readcenter(path+"center"+i.toString()+".txt");
			args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\1.txt", path+"input"+i.toString()};
			Main(args);
			writecenter(path+"center"+(i+1)+".txt");
		}
	}
}
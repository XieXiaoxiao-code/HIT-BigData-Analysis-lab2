package NAIVEBAYES;
import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.ujmp.core.DenseMatrix;

public class trainReducer
    extends Reducer<Text, Text, NullWritable, Text>{	
	
	public static boolean first = true;
	
    public void reduce(Text key, Iterable<Text> values, Context context)
        throws IOException, InterruptedException{
    	if(first) {
    		first = false;
    		trainMain.possqr = DenseMatrix.Factory.zeros(trainMain.dim, trainMain.positive);
    		trainMain.negsqr = DenseMatrix.Factory.zeros(trainMain.dim, trainMain.negative);
    		trainMain.pos = trainMain.pos.divide(trainMain.positive);
    		trainMain.neg = trainMain.neg.divide(trainMain.negative);
    		trainMain.positive = 0;
    		trainMain.negative = 0;    		
    	}
    	for(Text value:values) {
        	trainMain.calsqr(value.toString());
        	context.write(NullWritable.get(), value);
    	}
    }
}
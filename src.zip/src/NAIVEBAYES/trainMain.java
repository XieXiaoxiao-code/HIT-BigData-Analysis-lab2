package NAIVEBAYES;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;


public class trainMain {

	public static Integer dim = 20;
	public static Integer positive = 0;
	public static Integer negative = 0;
	public static Matrix pos = DenseMatrix.Factory.zeros(dim, 1);
	public static Matrix neg = DenseMatrix.Factory.zeros(dim, 1);
	public static Matrix possqr = DenseMatrix.Factory.zeros(dim, 1);
	public static Matrix negsqr = DenseMatrix.Factory.zeros(dim, 1);
	public static Matrix possigma = DenseMatrix.Factory.zeros(dim, dim);
	public static Matrix negsigma = DenseMatrix.Factory.zeros(dim, dim);
	
	public static void calavg(String S) {
		String[] T = S.split(",");
		Matrix mat = DenseMatrix.Factory.zeros(dim, 1);
		for(int i=0;i<dim;i++) {
			mat.setAsDouble(Double.parseDouble(T[i]), i, 0);
		}
		if(T[20].equals("0")) {
			neg = neg.plus(mat);
			negative++;
		}
		else if(T[20].equals("1")) {
			pos = pos.plus(mat);
			positive++;
		}
	}
	
	public static void calsqr(String S) throws FileNotFoundException {
		String[] T = S.split(",");
		Matrix mat = DenseMatrix.Factory.zeros(dim, 1);
		for(int i=0;i<dim;i++) {
			mat.setAsDouble(Double.parseDouble(T[i]), i, 0);
		}
		if(T[20].equals("0")) {
			mat = neg.minus(mat);
			for(int i=0;i<dim;i++) {
				negsqr.setAsDouble(mat.getAsDouble(i, 0), i, negative);
			}
			negative++;
		}
		else if(T[20].equals("1")) {
			mat = pos.minus(mat);
			for(int i=0;i<dim;i++) {
				possqr.setAsDouble(mat.getAsDouble(i, 0), i, positive);
			}
			positive++;
		}
	}
	
	public static void write(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		for (int i=0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				write.print(possigma.getAsDouble(i, j)+" ");
			}
			write.println();
		}
		for (int i=0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				write.print(negsigma.getAsDouble(i, j)+" ");
			}
			write.println();
		}
		for(int i=0;i<dim;i++) {
			write.print(pos.getAsDouble(i, 0)+" ");
		}
		write.println();
		for(int i=0;i<dim;i++) {
			write.print(neg.getAsDouble(i, 0)+" ");
		}
		write.println();
		write.println(positive);
		write.println(negative);
		write.close();
	}
	
	public static void Main(String[] args) throws Exception {
        Job job = new Job();
        job.setJarByClass(trainMain.class);
        job.setJobName("Naive Bayes train");
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setMapperClass(trainMapper.class);
        job.setReducerClass(trainReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
    }
	
	public static void main(String[] args) throws Exception {
		args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\2.txt", "C:\\Users\\xiexiaoxiao\\Desktop\\output5"};
		Main(args);
		possigma = possqr.mtimes(possqr.transpose());
		negsigma = negsqr.mtimes(negsqr.transpose());
		write("G:\\naivebayes\\init.txt");
	}

}

package NAIVEBAYES;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

import GMM.Function;

public class testMain {
	
	public static Integer dim = 20;
	public static Matrix possigma = DenseMatrix.Factory.zeros(dim, dim);
	public static Matrix negsigma = DenseMatrix.Factory.zeros(dim, dim);
	public static Matrix posmiu = DenseMatrix.Factory.zeros(dim, 1);
	public static Matrix negmiu = DenseMatrix.Factory.zeros(dim, 1);
	public static Double pospos = 0.0;
	public static Double posneg = 0.0;
	public static Double negneg = 0.0;
	public static Double negpos = 0.0;
	public static Double positive = 0.0;
	public static Double negative = 0.0;
	
	public static void read(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		for(int i=0;i<dim;i++) {
			String[] T = sc.nextLine().toString().split(" ");
			for(int j=0;j<dim;j++) {
				if(i==j) {
					possigma.setAsDouble(Double.parseDouble(T[j]), i, j);
				}
			}
		}
		for(int i=0;i<dim;i++) {
			String[] T = sc.nextLine().toString().split(" ");
			for(int j=0;j<dim;j++) {
				if(i==j) {
					negsigma.setAsDouble(Double.parseDouble(T[j]), i, j);
				}
			}
		}
		System.out.println(negsigma.det());
		String[] T = sc.nextLine().toString().split(" ");
		for(int i=0;i<dim;i++) {
			posmiu.setAsDouble(Double.parseDouble(T[i]), i, 0);
		}
		T = sc.nextLine().toString().split(" ");
		for(int i=0;i<dim;i++) {
			negmiu.setAsDouble(Double.parseDouble(T[i]), i, 0);
		}
		positive = Double.parseDouble(sc.nextLine());
		negative =Double.parseDouble(sc.nextLine());
		possigma = possigma.divide(positive);
		negsigma = negsigma.divide(negative);
		sc.close();
	}
	
	public static void CLASS(String S) {
		String[] T = S.split(",");
		Matrix y = DenseMatrix.Factory.zeros(dim, 1);
		for(int i=0;i<dim;i++) {
			y.setAsDouble(Double.parseDouble(T[i]), i, 0);
		}
		Double p1 = Function.gauss(y, posmiu, possigma);
		Double p2 = Function.gauss(y, negmiu, negsigma);
		if(p1>p2&&T[20].equals("1")) {
			pospos++;
		}
		if(p1>p2&&T[20].equals("0")) {
			negpos++;
		}
		if(p2>p1&&T[20].equals("1")) {
			posneg++;
		}
		if(p2>p1&&T[20].equals("0")) {
			negneg++;
		}
	}
	
	public static void Main(String[] args) throws Exception {
        Job job = new Job();
        job.setJarByClass(testMain.class);
        job.setJobName("Naive Bayes test");
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setMapperClass(testMapper.class);
        job.setNumReduceTasks(0);
        job.setReducerClass(testReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
    }
	
	public static void main(String[] args) throws Exception {
		read("G:\\naivebayes\\init.txt");
		args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\2.txt", "C:\\Users\\xiexiaoxiao\\Desktop\\output6"};
		Main(args);
		System.out.println(pospos+" "+posneg+" "+negpos+" "+negneg);
		System.out.println("positive true rate: "+pospos/(pospos+posneg));
		System.out.println("positive false rate: "+posneg/(pospos+posneg));
		System.out.println("negtive true rate: "+negneg/(negneg+negpos));
		System.out.println("negtive false rate: "+negpos/(negneg+negpos));
	}
}

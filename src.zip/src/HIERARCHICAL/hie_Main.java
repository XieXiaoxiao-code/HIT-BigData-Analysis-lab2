package HIERARCHICAL;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import TUPLE.DoubleTuple;
import TUPLE.NewArrayList;


public class hie_Main {
	public static ArrayList<Integer> setnum = new  ArrayList<>();
	public static Integer num = 0;
	public static ArrayList<DoubleTuple> coordinate = new  ArrayList<>();
	public static Double[][] distance;
	
	public static void DistanceInit() {
    	distance = new Double[num][num];
    	for (int i = 0; i < num; i++) {
    		for (int j = 0; j < num; j++) {
    			if(i!=j) {
    				distance[i][j] = coordinate.get(i).getDistance(coordinate.get(j));
    			}
    			else {
    				distance[i][j] = 0.0;
    			}
    		}
    	}
	}
	
	public static void HieInit(String[] arg) throws Exception {
        Job job = new Job();
        job.setJarByClass(hie_Main.class);
        job.setJobName("Hierarchical cluster");
        
        FileInputFormat.addInputPath(job, new Path(arg[0]));
        FileOutputFormat.setOutputPath(job, new Path(arg[1]));

        job.setMapperClass(hie_init_Mapper.class);
        job.setReducerClass(hie_init_Reducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
	}
	
	public static void optimize() throws FileNotFoundException {
		int setsize = num;
		PrintWriter write = new PrintWriter(new File("C:\\Users\\xiexiaoxiao\\Desktop\\sysout.txt"));
		while(setsize > 18) {
			getMinDistance(write);
			setsize--;
			System.out.println(setsize);
		}
		write.close();
		HashMap<Integer, NewArrayList<DoubleTuple>> center = new HashMap<>();
		ArrayList<Integer> kind = new ArrayList<>();
		for (int i = 0;i<num;i++) {
			if (center.containsKey(setnum.get(i))) {
				center.get(setnum.get(i)).add(coordinate.get(i));
			}
			else {
				center.put(setnum.get(i), new NewArrayList<DoubleTuple>(coordinate.get(i)));
				kind.add(setnum.get(i));
			}
		}
		PrintWriter W = new PrintWriter(new File("G:\\kmeans\\center0.txt"));
		for(Integer i: kind) {
			W.println(center.get(i).getcenter().toString());
		}
		System.out.println(center.size());
		W.close();
	}
	
	public static void getMinDistance(PrintWriter write) throws FileNotFoundException {
		for (int i = 0;i<num;i++) {
			for (int j = 0; j<num;j++) {
				write.print(String.format("%.2f", distance[i][j])+" ");
			}
			write.println("");
		}
		write.println("");
		Integer min_i = 0;
		Integer min_j = 0;
		Double dis_min = Double.MAX_VALUE;
		for (int i = 0; i<num;i++) {
			for(int j=0; j<num;j++) {
				Double dis_now = distance[i][j];
				if(i!=j&&dis_now>0.0&&dis_now<dis_min) {
					dis_min = dis_now;
					min_i = i;
					min_j = j;
				}
			}
		}
		int a = setnum.get(min_i);
		int b = setnum.get(min_j);
		int minnum = a>b?b:a;
		System.out.println(min_i+" "+min_j);
		System.out.println(distance[min_i][min_j]);
		System.out.println(a+" "+b);
		distance[min_i][min_j]=0.0;
		ArrayList<Integer> nowset = new ArrayList<>();
		ArrayList<Double> nowdis = new ArrayList<>();
		for(int i=0;i<num;i++) {
			if(setnum.get(i)==a||setnum.get(i)==b) {
				setnum.set(i, minnum);
				nowset.add(i);
			}
		}
		for(int i = 0; i<num; i++) {
				nowdis.add(distance[min_i][i]>distance[min_j][i]?distance[min_j][i]:distance[min_i][i]);
		}
		for (int i = 0;i<nowset.size();i++) {
			for (int j = 0; j<num;j++) {
				distance[nowset.get(i)][j] = nowdis.get(j);
				distance[j][nowset.get(i)] = nowdis.get(j);
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\1.txt", "C:\\Users\\xiexiaoxiao\\Desktop\\output3"};
		HieInit(args);
	}
}

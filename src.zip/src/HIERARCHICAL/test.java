package HIERARCHICAL;

import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;
import org.ujmp.core.calculation.Calculation;

import GMM.Function;

public class test {
	
	public static void main(String[] args) {
		Matrix y = DenseMatrix.Factory.zeros(2, 1);
		Matrix miu = DenseMatrix.Factory.zeros(2, 1);
		Matrix sigma = DenseMatrix.Factory.zeros(2, 2);
		y.setAsDouble(0, 0, 0);
		y.setAsDouble(0, 1, 0);
		miu.setAsDouble(0, 0, 0);
		miu.setAsDouble(0, 1, 0);
		sigma.setAsDouble(1, 0, 0);
		sigma.setAsDouble(1, 1, 1);
		sigma.setAsDouble(0, 1, 0);
		sigma.setAsDouble(0, 0, 1);
		System.out.println(y);
		System.out.println(miu);
		System.out.println(sigma);
		System.out.println(Function.gauss(y, miu, sigma));
		System.out.println(Function.getmatrix("1.0,1.1,1.2"));
	}

}

package HIERARCHICAL;
import java.io.IOException;
import java.util.Random;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import TUPLE.DoubleTuple;

public class hie_init_Mapper
    extends Mapper<LongWritable, Text, Text, Text>{
	public static Integer i = 0;
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
    	Random random = new Random();
    	if(random.nextInt(5000)==404) {
            context.write(new Text(key.toString()), value);
            hie_Main.setnum.add(hie_Main.num);
            hie_Main.num++;
            hie_Main.coordinate.add(new DoubleTuple(value.toString()));
    	}
    	i++;
    }
}
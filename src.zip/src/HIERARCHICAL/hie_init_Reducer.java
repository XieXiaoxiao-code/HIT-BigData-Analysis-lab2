package HIERARCHICAL;
import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import TUPLE.DoubleTuple;

public class hie_init_Reducer
    extends Reducer<Text, Text, NullWritable, Text>{
	public static boolean yes = true;
	
    public void reduce(Text key, Iterable<Text> values, Context context)
        throws IOException, InterruptedException{
    	for (Text value: values) {
        	context.write(NullWritable.get(), value);
    	}   	
    	if(yes) {
        	hie_Main.DistanceInit();
        	hie_Main.optimize(); 
        	yes=false;
    	}
    }
}
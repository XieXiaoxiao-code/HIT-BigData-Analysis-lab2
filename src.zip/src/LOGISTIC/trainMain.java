package LOGISTIC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;


public class trainMain {
	public static Integer dim = 20;
	
	public static Matrix w = DenseMatrix.Factory.zeros(dim+1, 1);
	public static Matrix t = DenseMatrix.Factory.zeros(dim+1, 1);
	public static Double rate = 1E-6;
	
	public static Double calexp(Matrix x, Matrix W) {
		Double a = W.transpose().mtimes(x).getAsDouble(0, 0);
		Double e = 0.0;
		if(a>100) {
			e = 1.0;
		}
		else if(a<-100) {
			e = 0.0;
		}
		else {
			e = Math.pow(Math.E, a)/(Math.pow(Math.E, a)+1);
		}
		return e;
	}
	
	public static void write(String filepath) throws FileNotFoundException {
		PrintWriter write = new PrintWriter(new File(filepath));
		for(int i=0;i<dim+1;i++) {
			write.print(w.getAsDouble(i, 0)+" ");
		}
		write.println();
		write.println(t);
		write.close();
	}
	
	public static void Main(String[] args) throws Exception {
        Job job = new Job();
        job.setJarByClass(trainMain.class);
        job.setJobName("Logistic train");
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setMapperClass(trainMapper.class);
        job.setNumReduceTasks(0);
        job.setReducerClass(trainReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
    }
	
	public static void main(String[] args) throws Exception {
		String filepath = "G:\\logistic\\";
		for(Integer i = 0;i<50;i++) {
			t = DenseMatrix.Factory.zeros(dim+1, 1);
			args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\2.txt", "G:\\logistic\\output"+i.toString()};
			Main(args);
			w = w.minus(t.times(rate));
			write(filepath+i.toString()+".txt");
		}
	}
}

package LOGISTIC;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class trainMapper
    extends Mapper<LongWritable, Text, Text, Text>{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
    	String[] T = value.toString().split(",");
    	Matrix x = DenseMatrix.Factory.ones(trainMain.dim+1, 1);
    	Double y = Double.parseDouble(T[20]);
    	for(int i=0;i<trainMain.dim;i++) {
    		x.setAsDouble(Double.parseDouble(T[i]), i, 0);    		
    	}
    	trainMain.t = trainMain.t.plus(trainMain.w.times(trainMain.calexp(x, trainMain.w)).minus(x.times(y)));
    }
}
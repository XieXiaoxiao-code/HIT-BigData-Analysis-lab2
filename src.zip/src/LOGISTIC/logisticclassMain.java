package LOGISTIC;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class logisticclassMain {
	
	public static Integer dim = 20;
	public static Matrix w = DenseMatrix.Factory.zeros(dim+1, 1);
	public static PrintWriter write;
	public static Double pospos = 0.0;
	public static Double posneg = 0.0;
	public static Double negneg = 0.0;
	public static Double negpos = 0.0;
	public static Double positive = 0.0;
	public static Double negative = 0.0;
	
	public static void readw(String filepath) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filepath));
		String[] T = sc.nextLine().split(" ");
		for(int i = 0;i<dim+1;i++) {
			w.setAsDouble(Double.parseDouble(T[i]), i, 0);
		}
		sc.close();
	}
	
	public static void Main(String[] args) throws Exception {
        Job job = new Job();
        job.setJarByClass(logisticclassMain.class);
        job.setJobName("Logistic test");
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        job.setMapperClass(logisticclassMapper.class);
        job.setNumReduceTasks(0);
        job.setReducerClass(logisticclassReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.waitForCompletion(true);
    }
	
	public static void main(String[] args) throws Exception {
		String filepath = "G:\\w.txt";
		readw(filepath);
		args = new String[] {"C:\\Users\\xiexiaoxiao\\Desktop\\4.txt", "G:\\logistic\\result"};
		write = new PrintWriter("G:\\logistic\\result.txt");
		Main(args);
		write.close();
	}

}

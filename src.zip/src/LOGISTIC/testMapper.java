package LOGISTIC;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class testMapper
    extends Mapper<LongWritable, Text, Text, Text>{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
    	String[] T = value.toString().split(",");
    	Matrix x = DenseMatrix.Factory.ones(trainMain.dim+1, 1);
    	for(int i=0;i<trainMain.dim;i++) {
    		x.setAsDouble(Double.parseDouble(T[i]), i, 0);    		
    	}
    	Double compare = x.transpose().mtimes(testMain.w).getAsDouble(0, 0);
    	if(compare>0&&T[20].equals("1")) {
    		testMain.pospos++;
    	}
    	else if(compare<0&&T[20].equals("1")) {
    		testMain.posneg++;
    	}
    	else if(compare>0&&T[20].equals("0")) {
    		testMain.negpos++;
    	}
    	else if(compare<0&&T[20].equals("0")) {
    		testMain.negneg++;
    	}
    }
}
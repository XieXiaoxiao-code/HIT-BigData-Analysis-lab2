package TUPLE;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class NewArrayList<T> extends ArrayList<T> {
	
	private ArrayList<DoubleTuple> NEW = new ArrayList<DoubleTuple>();
	
	public NewArrayList(DoubleTuple d){
		NEW.add(d);
	}
	
	
	public boolean add(DoubleTuple d) {
		if(d!=null) {
			NEW.add(d);
			return true;
		}
		return false;
	}
	
	public DoubleTuple getcenter() {
		int length = NEW.size();
		int n = NEW.get(0).length();
		Double[] sum = new Double[n];
		for(int i=0;i<n;i++) {
			sum[i] = 0.0;
		}
		for(int i=0;i<length;i++) {
			for(int j=0;j<n;j++) {
				sum[j] += NEW.get(i).get(j);
			}			
		}
		for(int i=0;i<n;i++) {
			sum[i] = sum[i]/length;
		} 
		return new DoubleTuple(sum);
	}

}

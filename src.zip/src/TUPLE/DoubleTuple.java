package TUPLE;

import java.util.ArrayList;

import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;

public class DoubleTuple {
	private ArrayList<Double> tuple = new ArrayList<>();
	public DoubleTuple(String s) {
		String[] T = s.split(",");
		int length = T.length;
		for (int i=0;i<length;i++) {
			tuple.add(Double.parseDouble(T[i]));
		}
	}
	public DoubleTuple(Double[] s) {
		int length = s.length;
		for (int i=0;i<length;i++) {
			tuple.add(s[i]);
		}
	}
	/** Return the single subject from the tuple with index
	 * 
	 * @param i index
	 * @return related subject
	 */
	public Double get(Integer i){
		return tuple.get(i);
	}
	
	/** For a whole return
	 * 
	 * @return
	 */
	public Object getall(){
		return tuple.clone();
	}
	
	/** Return the length of tuple
	 * 
	 * @return
	 */
	public Integer length() {
		return tuple.size();
	}
	
	public Double getDistance(DoubleTuple node) {
		Double sum = 0.0;
		int n = tuple.size();
		for (int i = 0; i < n; i++) {
			sum += Math.pow(tuple.get(i)-node.get(i), 2);
		}
		return sum;
	}
	
	public String toString() {
		StringBuffer cache = new StringBuffer();
		for(int i=0;i<tuple.size()-1;i++) {
			cache.append(tuple.get(i).toString()+",");
		}
		cache.append(tuple.get(tuple.size()-1).toString());
		return cache.toString();
	}
	
}
